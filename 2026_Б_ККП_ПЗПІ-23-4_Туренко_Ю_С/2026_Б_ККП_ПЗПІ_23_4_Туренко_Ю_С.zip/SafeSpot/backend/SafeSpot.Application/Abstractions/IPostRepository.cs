﻿using SafeSpot.Domain.Entities;

namespace SafeSpot.Application.Abstractions;

public interface IPostRepository : IRepository<Post>
{
    Task<List<Post>> GetByShelterIdAsync(long shelterId);
}