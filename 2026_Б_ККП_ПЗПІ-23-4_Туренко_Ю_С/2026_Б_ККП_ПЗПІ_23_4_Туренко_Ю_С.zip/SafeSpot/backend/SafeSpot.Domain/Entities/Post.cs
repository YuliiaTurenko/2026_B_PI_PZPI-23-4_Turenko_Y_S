﻿namespace SafeSpot.Domain.Entities;

public class Post : BaseEntity
{
    public long UserId { get; set; }
    public virtual User User { get; set; }

    public long ShelterId { get; set; }
    public virtual Shelter Shelter { get; set; }

    public required string Text { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();
}
