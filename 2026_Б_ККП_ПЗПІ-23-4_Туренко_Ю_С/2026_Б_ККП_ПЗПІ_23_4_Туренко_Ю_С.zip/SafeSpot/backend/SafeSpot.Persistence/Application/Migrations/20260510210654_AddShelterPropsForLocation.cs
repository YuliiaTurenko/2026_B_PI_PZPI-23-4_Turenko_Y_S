﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SafeSpot.Persistence.Application.Migrations
{
    /// <inheritdoc />
    public partial class AddShelterPropsForLocation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Location",
                schema: "SafeSpot",
                table: "Shelters",
                newName: "Address");

            migrationBuilder.AddColumn<double>(
                name: "Latitude",
                schema: "SafeSpot",
                table: "Shelters",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "Longitude",
                schema: "SafeSpot",
                table: "Shelters",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Latitude",
                schema: "SafeSpot",
                table: "Shelters");

            migrationBuilder.DropColumn(
                name: "Longitude",
                schema: "SafeSpot",
                table: "Shelters");

            migrationBuilder.RenameColumn(
                name: "Address",
                schema: "SafeSpot",
                table: "Shelters",
                newName: "Location");
        }
    }
}
