﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SafeSpot.Persistence.Application.Migrations
{
    /// <inheritdoc />
    public partial class UpdateSensor : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "CurrentValue",
                schema: "SafeSpot",
                table: "Sensors",
                type: "float",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastSeenAt",
                schema: "SafeSpot",
                table: "Sensors",
                type: "datetime2",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CurrentValue",
                schema: "SafeSpot",
                table: "Sensors");

            migrationBuilder.DropColumn(
                name: "LastSeenAt",
                schema: "SafeSpot",
                table: "Sensors");
        }
    }
}
