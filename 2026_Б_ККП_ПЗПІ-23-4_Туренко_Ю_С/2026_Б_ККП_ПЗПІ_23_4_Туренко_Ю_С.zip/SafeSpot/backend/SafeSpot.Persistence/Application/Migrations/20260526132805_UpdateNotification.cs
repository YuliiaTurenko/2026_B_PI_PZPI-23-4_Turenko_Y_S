﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SafeSpot.Persistence.Application.Migrations
{
    /// <inheritdoc />
    public partial class UpdateNotification : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsRead",
                schema: "SafeSpot",
                table: "Notifications",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "Type",
                schema: "SafeSpot",
                table: "Notifications",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsRead",
                schema: "SafeSpot",
                table: "Notifications");

            migrationBuilder.DropColumn(
                name: "Type",
                schema: "SafeSpot",
                table: "Notifications");
        }
    }
}
